// File: Assignment2Main.java
// Name: Amarjit Singh
// Date: 3/7/2016
// Course: CSc 130
// Desc: Program simulates a store
//
// Usage: test weather express lines are really useful
//

public class Assignment2Main {
	public static void main(String[] args) {

	    CreateCust obj1 = new CreateCust();//creating customer object
	    
	    obj1.CreateCustomer();//calling customer object

	}
}
