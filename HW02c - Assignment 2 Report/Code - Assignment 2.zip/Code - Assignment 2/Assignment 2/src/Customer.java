// File: Customer.java
// Name: Amarjit Singh
// Date: 3/7/2016
// Course: CSc 130
// Desc: Program simulates a store
//
// Usage: test weather express lines are really useful
//

public class Customer {
	private int nCustomer;
	private int nItems;
//--------------------------------------------------------------
	public Customer(int cust, int item){                               // constructor
		nCustomer = cust;
		nItems = item;
	}
	public void displayCustomer(){
		 System.out.println("      " + nCustomer + "         |      " + nItems + "     ");
    }
	public int getItems(){          // get number of items
		return nItems;
	}
	public int getCustomer(){          // get last name
		return nCustomer;
	}
}
